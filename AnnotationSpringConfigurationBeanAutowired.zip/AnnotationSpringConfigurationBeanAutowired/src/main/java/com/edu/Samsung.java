package com.edu;

import org.springframework.beans.factory.annotation.Autowired;

public class Samsung {

	@Autowired
	MobileProcessor mcp;

	public MobileProcessor getMcp() {
		return mcp;
	}

	public void setMcp(MobileProcessor mcp) {
		this.mcp = mcp;
	}
	
	public void MobileConfig(){
		System.out.println("8gb RAM Dual Core 128Px Camera");
		mcp.processor();
	}
}
