package com.edu;

public class SnapDragon implements MobileProcessor{

	public void processor() {
	
		System.out.println("World Best Processor");
	}
	

}
