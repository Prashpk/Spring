package com.edu;

public class TextEditor {

private SpellChecker spell;

public SpellChecker getSpell() {
	return spell;
}

public void setSpell(SpellChecker spell) {
	this.spell = spell;
}


public void textfunc() {
	if(spell!= null) {
		spell.spellFunc();
	}
	else {
		System.out.println("Spell check is disabled!");
	}
}

}
