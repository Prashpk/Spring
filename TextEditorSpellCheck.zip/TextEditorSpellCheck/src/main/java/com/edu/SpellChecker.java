package com.edu;

public class SpellChecker {

	public void spellFunc() {
		System.out.println("Spell check is enabled");
	}

}
