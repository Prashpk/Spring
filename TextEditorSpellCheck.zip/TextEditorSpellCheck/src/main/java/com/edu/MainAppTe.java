package com.edu;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {

		ApplicationContext xmt = new ClassPathXmlApplicationContext("spring.xml");
		TextEditor tob = (TextEditor) xmt.getBean("textobj");
		tob.textfunc();
	}

}
