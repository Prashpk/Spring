package com.edu;

public class Student {
	public void display() {
		System.out.println("My first Spring Application");
	}

}
