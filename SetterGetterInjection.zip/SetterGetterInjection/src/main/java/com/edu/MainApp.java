package com.edu;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {

		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		
		Product pr = (Product) context.getBean("prod");
		pr.display();
		
		Product pr1 = (Product) context.getBean("prod1");
		pr1.display();
		
		Product pr2 = (Product) context.getBean("prod2");
		pr2.display();
	}

}
