package com.edu;

public class Student {

	public void display() {
		System.out.println("Hello Spring, This is My First Spring App");
	}
	//creating constructor
	Student(){
		System.out.println("I am constructor called");
	}
}
